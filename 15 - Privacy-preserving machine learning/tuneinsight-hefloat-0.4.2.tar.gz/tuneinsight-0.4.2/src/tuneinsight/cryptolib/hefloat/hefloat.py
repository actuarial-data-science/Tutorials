from typing import List
import numpy as np
from tuneinsight.lattigo.parameters import new_parameters, Parameters
from tuneinsight.lattigo import keygenerator
from tuneinsight.lattigo.encoder import new_encoder
from tuneinsight.lattigo.encryptor import new_encryptor
from tuneinsight.lattigo.decryptor import new_decryptor
from tuneinsight.lattigo.keys import SecretKey, PublicKey, RelinearizationKey, new_evaluation_key_set
from tuneinsight.lattigo.operands import new_plaintext, new_ciphertext
from tuneinsight.lattigo.operands import Ciphertext as operand_Ciphertext
from tuneinsight.lattigo.evaluator import new_evaluator
from tuneinsight.lattigo.polynomial import Polynomial

class Ciphertext():
    def __init__(self, Ciphertexts:List[operand_Ciphertext]=None):
        self.Ciphertexts = Ciphertexts

    def free(self):
        for ct in self.Ciphertexts:
            ct.free()

    def __getitem__(self, key):
        return self.Ciphertexts[key]

    def __len__(self):
        return len(self.Ciphertexts)

    def __contains__(self, key):
        return key in self.Ciphertexts

    def is_batched(self):
        return self.Ciphertexts[0].is_batched()

    def set_is_batched(self, is_batched:bool):
        for ct in self.Ciphertexts:
            ct.set_is_batched(is_batched)


class Evaluator():
    def __init__(self, parameters: Parameters, rlk: RelinearizationKey):
        self.parameters = parameters
        self.evaluator = new_evaluator(parameters, new_evaluation_key_set(rlk, None))

    #pylint: disable=R0201, R0912
    def evaluate_operation(self, op0:Ciphertext, op1: [int, float, complex, np.ndarray, Ciphertext], op2:Ciphertext, op) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if not isinstance(op2, Ciphertext):
            raise ValueError("invalid op2 type: must be Ciphertext")

        if isinstance(op1, (int, float, complex)):
            for i, _ in enumerate(op0):
                op(op0[i], op1, op2[i])

        elif isinstance(op1, np.ndarray):
            shape = op1.shape
            if shape[0] == len(op0):
                for i, _ in enumerate(op0):
                    op(op0[i], op1[i], op2[i])
            elif shape[0] == 1:
                for i, _ in enumerate(op0):
                    op(op0[i], op1[0], op2[i])
            else:
                raise ValueError("invalid op1.shape[0], must be equal to op0.shape[0] or 1")

        elif isinstance(op1, Ciphertext):
            if len(op1) == len(op0):
                for i, _  in enumerate(op0):
                    op(op0[i], op1[i], op2[i])
            elif len(op1) == 1:
                for i, _  in enumerate(op0):
                    op(op0[i], op1[0], op2[i])
            else:
                raise ValueError("invalid len(op1), must be equal to len(op0) or 1")
        else:
            raise ValueError("invalid op1")

        return op2

    def add(self, op0:Ciphertext, op1: [int, float, complex, np.ndarray, Ciphertext], op2:Ciphertext=None) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if op2 is None:
            cts = []
            for ct in op0:
                cts += [new_ciphertext(self.parameters, ct.degree(), ct.level())]
            op2 = Ciphertext(cts)
        else:

            if not isinstance(op2, Ciphertext):
                raise ValueError("invalid op2 type: must be Ciphertext")

            if len(op2) != len(op0):
                raise ValueError("invalid len(op2), must be equal to len(op0)")

        return self.evaluate_operation(op0, op1, op2, self.evaluator.add)

    def mul(self, op0:Ciphertext, op1: [int, float, complex, np.ndarray, Ciphertext], op2:Ciphertext=None, relinearize:bool=True) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if op2 is None:
            cts = []
            for ct in op0:
                cts += [new_ciphertext(self.parameters, ct.degree(), ct.level())]
            op2 = Ciphertext(cts)
        else:

            if not isinstance(op2, Ciphertext):
                raise ValueError("invalid op2 type: must be Ciphertext")

            if len(op2) != len(op0):
                raise ValueError("invalid len(op2), must be equal to len(op0)")


        def mul(op0:Ciphertext, op1: [int, float, complex, np.ndarray, Ciphertext], op2:Ciphertext):
            return self.evaluator.mul(op0, op1, op2, relinearize)

        op2 = self.evaluate_operation(op0, op1, op2, mul)

        if not isinstance(op1, int):
            for ct in op2:
                self.evaluator.rescale(ct, ct)

        return op2

    def scalar_product(self, op0:Ciphertext, op1:Ciphertext) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid op1 type: must be Ciphertext")

        if len(op0) != len(op1):
            raise ValueError("invalid len(op1), must be equal to len(op0)")

        tmp0 = new_ciphertext(self.parameters, 2, op0[0].level())
        tmp1 = new_ciphertext(self.parameters, 2, op0[0].level())

        for i, _ in enumerate(op0):
            self.evaluator.mul(op0[i], op1[i], tmp0, relinearize=False)
            self.evaluator.add(tmp1, tmp0, tmp1)

        self.evaluator.relinearize(tmp1, tmp1)

        self.evaluator.rescale(tmp1, tmp1)

        tmp0.free()

        return Ciphertext([tmp1])

    def sum(self, op0:Ciphertext, axis:int=0) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if axis != 0:
            raise ValueError("invalid axis: method is only implemented for axis=0")

        if axis == 0:
            op1 = Ciphertext([new_ciphertext(self.parameters, op0[0].degree(), op0[0].level())])
            for i, _ in enumerate(op0):
                self.evaluator.add(op1[0], op0[i], op1[0])

        return op1

    def polynomial(self, op0:Ciphertext, coeffs: np.ndarray, basis:str, op2:Ciphertext=None) -> Ciphertext:

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid op0 type: must be Ciphertext")

        if not isinstance(coeffs, np.ndarray):
            raise ValueError("invalid coeffs type: must be np.ndarray")

        if len(coeffs.shape) != 1:
            raise ValueError("invalid coeffs: dimensions must be 1 (vector)")

        if op2 is None:
            cts = []
            for ct in op0:
                cts += [new_ciphertext(self.parameters, ct.degree(), ct.level())]
            op2 = Ciphertext(cts)
        else:
            if not isinstance(op2, Ciphertext):
                raise ValueError("invalid op2 type: must be Ciphertext")

        poly = Polynomial(coeffs=coeffs, basis=basis)

        for i, _ in enumerate(op0):
            self.evaluator.polynomial(op0[i], poly, op2[i])

        return op2

class Context():
    def __init__(self, log_qi: List[int], log_default_scale: int, log_pi: List[int]):
        self.parameters = new_parameters(log_qi, log_default_scale, log_pi)
        self.key_generator = keygenerator.new_key_generator(self.parameters)
        self.encoder = new_encoder(self.parameters)

    def slots(self):
        return self.parameters.slots()

    def new_secret_key(self) -> SecretKey:
        return self.key_generator.gen_secret_key()

    def new_public_key(self, secret_key: SecretKey) -> PublicKey:
        return self.key_generator.gen_public_key(secret_key)

    def new_relinearization_key(self, secret_key: SecretKey) -> RelinearizationKey:
        return self.key_generator.gen_relinearization_key(secret_key)

    def new_evaluator(self, rlk: RelinearizationKey) -> Evaluator:
        return Evaluator(self.parameters, rlk)

    def encrypt(self, data: np.ndarray, secret_key: SecretKey, batched: bool=True) -> Ciphertext:

        if not isinstance(data, np.ndarray):
            raise ValueError("invalid data type: must be np.ndarray")

        if not isinstance(secret_key, SecretKey):
            raise ValueError("invalid secret_key type: must be SecretKey")

        if not isinstance(batched, bool):
            raise ValueError("invalid batched type: must be bool")

        pt = new_plaintext(self.parameters)
        pt.set_is_batched(batched)

        encryptor = new_encryptor(self.parameters, secret_key)

        shape = data.shape

        if len(shape) > 2:
            raise ValueError(
                "invalid np.ndarray.shape: must be 1D or 2D")

        slots = self.parameters.slots()

        if shape[1] > slots:
            raise ValueError(
                f'invalid np.ndarray.shape[1]: should be <={slots}')

        ctx = []
        for i in data:
            self.encoder.encode(i, pt)
            ctx += [encryptor.encrypt(pt)]

        pt.free()
        encryptor.free()

        return Ciphertext(ctx)

    def decrypt(self, ct: Ciphertext, secret_key: SecretKey, dtype: str="float") -> np.ndarray:

        if not isinstance(ct, Ciphertext):
            raise ValueError("invalid ct type: must be Ciphertext")

        if not isinstance(secret_key, SecretKey):
            raise ValueError("invalid secret_key type: must be SecretKey")

        if not isinstance(dtype, str):
            raise ValueError("invalid dtype type: must be str")

        decryptor = new_decryptor(self.parameters, secret_key)

        slots = self.parameters.slots()

        res = np.zeros((len(ct), slots), dtype=dtype)

        for i, _ in enumerate(ct):
            pt = decryptor.decrypt(ct[i])
            self.encoder.decode(pt, res[i])
            pt.free()

        decryptor.free()

        return res

def new_context(log_qi: List[int], log_default_scale: int, log_pi: List[int]) -> Context:

    if not isinstance(log_qi, List):
        raise ValueError("invalid log_qi type: must be List[int]")

    if not isinstance(log_default_scale, int):
        raise ValueError("invalid log_default_scale type: must be int")

    if not isinstance(log_pi, List):
        raise ValueError("invalid log_pi type: must be List[int]")

    return Context(log_qi, log_default_scale, log_pi)
