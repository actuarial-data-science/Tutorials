import ctypes
import numpy as np
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.object import Object
from tuneinsight.lattigo.keys import EvaluationKeySet
from tuneinsight.lattigo.operands import Plaintext, Ciphertext, new_plaintext
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.polynomial import Polynomial, basis_type_list
from tuneinsight.lattigo.encoder import new_encoder
from tuneinsight.lattigo.lineartransformation import LinearTransformation

class Evaluator(Object):
    """Evaluator is a class used to perform homomorphic operations on ciphertexts
    """
    def __init__(self, ID: str, params: Parameters):
        Object.__init__(self, ID)
        self.Parameters = params
        self.Encoder = new_encoder(params)

    def set_evaluation_key_set(self, evk: EvaluationKeySet):
        """Updates the evaluation key set of the evaluator to a new one.

        Args:
            evk (EvaluationKeySet): the new evaluation key set
        """

        if not isinstance(evk, EvaluationKeySet):
            raise ValueError("invalid input: evk must be of type EvaluationKeySet")

        setkeys = so.EvaluatorWithKey
        setkeys.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        setkeys.restype = ctypes.c_size_t

        if setkeys(self.ID, evk.ID) == 0:
            raise go_error()

    def rescale(self, op0: Ciphertext, op1: Ciphertext):
        """Performs the rescaling operation on a ciphertext. Divides the coefficients by the last
            modulus of the moduli chain of the ciphertext and returns a new ciphertext of one less
            level.

        Args:
            op0 (Ciphertext): the ciphertext to perform the rescaling operation on
            op1 (Ciphertext): the ciphertext to receive the result of the rescaling operation

        Notes:
            Rescaling is a

        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        rescale = so.Rescale
        rescale.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
        rescale.restype = ctypes.c_size_t

        if rescale(self.ID, op0.ID, op1.ID) == 0:
            raise go_error()

    def add(
            self,
            op0: Ciphertext,
            op1: [
                Ciphertext,
                Plaintext,
                int,
                float,
                complex,
                np.ndarray],
            op2: Ciphertext):

        """Performs a homomorphic addition op2 = op0 + op1

        Args:
            op0 (Ciphertext): the ciphertext to be added to
            op1 (int, float, complex, np.ndarray, Plaintext, Ciphertext): the value to add on op0
            op2 (Ciphertext): the ciphertext to receive the result of the addition

        Notes:
            If doing Ciphertext + Plaintext or Ciphertext + Ciphertext, the user should ensure that op0 and op1 scales
            are exactly the same to ensure noiseless addition and optimal accuracy.
            The scale of op2 is uptated to max(op0.scale(), op1.scale()).
            The level of op2 is updated to min(op0.level(), op1.level()).

        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op2, Ciphertext):
            raise ValueError("invalid input: op2 must be of type Ciphertext")

        if isinstance(op1, (Plaintext, Ciphertext)):

            add = so.AddOperand

            add.argtypes = [
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_char_p]
            add.restype = ctypes.c_size_t

            if add(self.ID, op0.ID, op1.ID, op2.ID) == 0:
                raise go_error()

        elif isinstance(op1, (int, float, complex)):

            add = so.AddScalar

            add.argtypes = [
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_double,
                ctypes.c_double,
                ctypes.c_char_p]
            add.restype = ctypes.c_size_t

            op1 = complex(op1)

            if add(self.ID, op0.ID, op1.real, op1.imag, op2.ID) == 0:
                raise go_error()

        elif isinstance(op1, np.ndarray):
            if op1.dtype in ["float", "complex"]:
                pt = new_plaintext(
                    self.Parameters, min(
                        op0.level(), op2.level()))
                pt.set_scale(op0.scale())
                self.Encoder.encode(op1, pt)
                self.add(op0, pt, op2)
                pt.free()
            else:
                raise ValueError(
                    "np.ndarray.dtype must be `float` or `complex`")
        else:
            raise ValueError("invalid second operand type")

    def mul(
            self,
            op0: Ciphertext,
            op1: [
                Ciphertext,
                Plaintext,
                int,
                float,
                complex,
                np.ndarray],
            op2: Ciphertext, relinearize: bool=True):
        """Performs a homomorphic multiplication op2 = op0 * op1

        Args:
            op0 (Ciphertext): the ciphertext to be added to
            op1 (int, float, complex, np.ndarray, Plaintext, Ciphertext): the value to multiply with op0
            op2 (Ciphertext): the ciphertext to receive the result of the multiplication

        Notes:
            If doing Ciphertext + Plaintext or Ciphertext + Ciphertext, the user should should try to ensure
            that either op0 or op1 scale is equal to Parameters.scale_at_level(min(op0.level(), op1.level()).
            This will ensure that the following rescaling operation is an exact division and returns the scale
            to a value equal to the one before the multiplication.
            The scale of op2 is uptated to op0.scale() * op1.scale().
            The level of op2 is updated to min(op0.level(), op1.level()).

        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op2, Ciphertext):
            raise ValueError("invalid input: op2 must be of type Ciphertext")

        if isinstance(op1, (Plaintext, Ciphertext)):

            if relinearize:
                mul = so.MulRelinOperand
            else:
                mul = so.MulOperand

            mul.argtypes = [
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_char_p]
            mul.restype = ctypes.c_size_t

            if mul(self.ID, op0.ID, op1.ID, op2.ID) == 0:
                raise go_error()

        elif isinstance(op1, (int, float, complex)):

            mul = so.MulScalar

            mul.argtypes = [
                ctypes.c_char_p,
                ctypes.c_char_p,
                ctypes.c_double,
                ctypes.c_double,
                ctypes.c_char_p]
            mul.restype = ctypes.c_size_t

            op1 = complex(op1)

            if mul(self.ID, op0.ID, op1.real, op1.imag, op2.ID) == 0:
                raise go_error()

        elif isinstance(op1, np.ndarray):
            if op1.dtype in ["float", "complex"]:
                pt = new_plaintext(
                    self.Parameters, min(
                        op0.level(), op2.level()))
                pt.set_scale(op0.scale())
                self.Encoder.encode(op1, pt)
                self.mul(op0, pt, op2)
                pt.free()
            else:
                raise ValueError(
                    "np.ndarray.dtype must be `float` or `complex`")
        else:
            raise ValueError("invalid second operand type")

    def relinearize(self, op0: Ciphertext, op1: Ciphertext):
        """Performs the relinearization on a ciphertext.

        Args:
            op0 (Ciphertext): the ciphertext to rotate.
            op1 (Ciphertext): the ciphertext to receive the result of the relinearization.

        Notes:
            The scale of op1 is uptated to op0.scale().
            The level of op1 is updated to min(op0.level(), op1.level()).
        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        relin = so.Relinearize
        relin.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p]
        relin.restype = ctypes.c_size_t

        if relin(self.ID, op0.ID, op1.ID) == 0:
            raise go_error()

    def rotate(self, op0: Ciphertext, k: int, op1: Ciphertext):
        """Performs a homomorphic cyclic rotation to the left by k positions on a ciphertext.

        Args:
            op0 (Ciphertext): the ciphertext to rotate.
            k (int): the amount to rotate by.
            op1 (Ciphertext): the ciphertext to receive the result of the rotation.

        Notes:
            The scale of op1 is uptated to op0.scale().
            The level of op1 is updated to min(op0.level(), op1.level()).
        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        if not isinstance(k, int):
            raise ValueError("invalid input: ,  must be of type int")

        rotate = so.EvaluateRotation
        rotate.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_char_p]
        rotate.restype = ctypes.c_size_t

        if rotate(self.ID, op0.ID, k, op1.ID) == 0:
            raise go_error()

    def conjugate(self, op0: Ciphertext, op1: Ciphertext):
        """Performs a homomorphic conjugation on a ciphertext.

        Args:
            op0 (Ciphertext): the ciphertext to conjugate.
            op1 (Ciphertext): the ciphertext to receive the result.

        Notes:
            The scale of op1 is uptated to op0.scale().
            The level of op1 is updated to min(op0.level(), op1.level()).
        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        conjugate = so.EvaluateConjugate
        conjugate.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p]
        conjugate.restype = ctypes.c_size_t

        if conjugate(self.ID, op0.ID, op1.ID) == 0:
            raise go_error()

    def polynomial(self, op0: Ciphertext, poly: Polynomial, op1: Ciphertext):
        """Performs a homomorphic polynomial evaluation on a ciphertext.

        Args:
            op0 (Ciphertext): the ciphertext to evaluate the polynomial on.
            poly (Polynomial): the polynomial to evaluate on the ciphertext.
            op1 (Ciphertext): the ciphertext to receive the result of the polynomial evaluation.

        Notes:
            The minimum level of op0 must be ceil(log2(polynomial_degree-1)).
            The level of op1 is updated to op0.level() - ceil(log2(polynomial_degree-1))
        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(poly, Polynomial):
            raise ValueError("invalid input: poly must be of type Ciphertext")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        eval_poly = so.EvaluatePolynomial
        eval_poly.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_double), ctypes.c_size_t,
            ctypes.c_size_t,
            ctypes.c_char_p,
        ]
        eval_poly.restype = ctypes.c_size_t

        if poly.basis == basis_type_list[0]:
            basis_int = 0
        else:
            basis_int = 1

        if eval_poly(
            self.ID, op0.ID, poly.coeffs.ctypes.data_as(
                ctypes.POINTER(
                    ctypes.c_double)), len(
                poly.coeffs), basis_int, op1.ID) == 0:
            raise go_error()

    def linear_transformation(
            self,
            op0: Ciphertext,
            lt: LinearTransformation,
            op1: Ciphertext):
        """Performs a homomorphic linear transformation on a ciphertext.

        Args:
            op0 (Ciphertext): the ciphertext to perform the linear transformation on.
            lt (LinearTransformation): the linear transformation.
            op1 (Ciphertext): the ciphertext to receive the result of the linear transformation.

        Notes:
            The scale of op1 is uptated to op0.scale() * lt.scale().
            The level of op1 is updated to min(op0.level(), lt.level()).
        """

        if not isinstance(op0, Ciphertext):
            raise ValueError("invalid input: op0 must be of type Ciphertext")

        if not isinstance(lt, LinearTransformation):
            raise ValueError("invalid input: lt must be of type LinearTransformation")

        if not isinstance(op1, Ciphertext):
            raise ValueError("invalid input: op1 must be of type Ciphertext")

        eval_lt = so.EvaluateLinearTransformation
        eval_lt.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p]
        eval_lt.restype = ctypes.c_size_t

        if lt.ID is None:
            raise ValueError(
                "linear transformation ID is NONE -> make sure it has been encoded")

        if eval_lt(self.ID, op0.ID, lt.ID, op1.ID) == 0:
            raise go_error()


def new_evaluator(params: Parameters, evk: EvaluationKeySet) -> Evaluator:
    """Instantiates a new Evaluator.

    Args:
        params (Parameters): the scheme parameters
        evk (EvaluationKeySet): a an evaluation key set

    Returns:
        Evaluator (Evaluator): a new instance of Evaluator
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    if not isinstance(evk, EvaluationKeySet):
        raise ValueError("invalid input: evk must be of type EvaluationKeySet")

    evaluator = so.NewEvaluator
    evaluator.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    evaluator.restype = ctypes.c_char_p
    ID = evaluator(params.ID, evk.ID)
    if ID is None:
        raise go_error()
    return Evaluator(ID, params)
