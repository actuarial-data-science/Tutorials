import ctypes
import json
from tuneinsight.lattigo.library import so


def free(ID: str):
    """Frees the memory from the object.
       The object is deleted from the map
       and the garbage collector is called.
    """
    f = so.FreeObject
    f.argtypes = [ctypes.c_char_p]
    f(ID)

def free_all():
    """Frees all the memory from any object.
    """
    so.FreeAll()

def exist(ID: str) -> bool:
    """Returns true if an object with the given ID exists in the memory.
    """
    f = so.ObjectExist
    f.argtypes = [ctypes.c_char_p]
    f.restype = ctypes.c_size_t

    if f(ID) == 1:
        return True
    return False

def list_all() -> dict:
    """Returns a dictionary {ID:object_type} listing all
       objects currently stored in the memory.
    """
    f = so.ListAllObjects
    f.restype = ctypes.c_char_p
    r = f()
    return json.loads(r)

class Object():
    """Object is a class defining an object with an ID.
    """
    def __init__(self, ID):
        self.ID = ID

    def free(self):
        """Frees the object from the memory.
           This operation cannot be reversed.
        """
        free(self.ID)

    def exist(self) -> bool:
        """Returns true if the object exists in the memory.
        """
        return exist(self.ID)
