import ctypes
import numpy as np
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.encoder import Encoder
from tuneinsight.lattigo.object import Object


class LinearTransformation(Object):
    """LinearTransformation is a class used to store a linear transformation,
       that can be evaluated on ciphertexts.
    """
    def __init__(self, params: Parameters, matrix: np.ndarray):
        Object.__init__(self, None)

        self.Parameters = params

        slots = 1 << params.log_slots()

        self.diags = {}

        rows = matrix.shape[0]
        cols = matrix.shape[1]

        for i in range(cols):

            diag = np.array([0 for i in range(slots)], dtype="complex")

            for j in range(rows - i):

                idx = j + i

                if idx >= cols:
                    break

                diag[j] = matrix[j][idx]

            if diag.any():
                self.diags[i] = diag[:]

        for i in range(1, rows):
            diag = np.array([0 for i in range(slots)], dtype="complex")

            for j in range(rows - i):

                idx = j + i

                if idx >= rows:
                    break

                diag[j] = matrix[idx][j]

            if diag.any():

                idx = slots - i

                if idx in self.diags:
                    self.diags[idx] += np.roll(diag, i)
                else:
                    self.diags[idx] = np.roll(diag, i)

    def galois_elements(self) -> list[int]:
        """Returns the list of Galois elements required to
           homomorphically evaluate the linear transformation.

        Returns:
            galEls (List[int]): the list of Galois elements.
        """
        galEls = so.GaloisElementsForLinearTransformation
        galEls.argtypes = [
            ctypes.c_char_p,
            ctypes.POINTER(
                ctypes.c_int),
            ctypes.c_int]
        galEls.restype = ctypes.POINTER(ctypes.c_size_t)

        keys = np.array(list(self.diags.keys()), dtype="int")

        g = galEls(
            self.Parameters.ID,
            keys.ctypes.data_as(
                ctypes.POINTER(
                    ctypes.c_int)),
            len(keys))

        if not g:
            raise go_error()

        return sorted(g[1:g[0] + 1])

    def encode(self, params: Parameters, encoder: Encoder, level: int):
        """Encodes the linear transformation from a two dimensional np.ndarray
           to an object that can be used for homomorphic evaluation.

        Args:
            encoder (Encoder): an encoder.
            level (int): the level at which to encode the linear transformation

        Notes:
            The linear transformation is encoded at the scale Parameters.scale_at_level(level).
        """

        if not isinstance(params, Parameters):
            raise ValueError("invalid input: params must be of type Parameters")

        if not isinstance(encoder, Encoder):
            raise ValueError("invalid input: encoder must be of type Encoder")

        if not isinstance(level, int):
            raise ValueError("invalid input: level must be of type int")


        keys = np.array(list(self.diags.keys()), dtype="int")
        diags = np.array(self.diags[keys[0]])

        for i in keys[1:]:
            diags = np.append(diags, self.diags[i])

        lt = so.EncodeLinearTransformation
        lt.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p, ctypes.POINTER(
                ctypes.c_double), ctypes.POINTER(
                ctypes.c_int), ctypes.c_int, ctypes.c_int]
        lt.restype = ctypes.c_char_p

        ID = lt(
            params.ID,
            encoder.ID, diags.ctypes.data_as(
                ctypes.POINTER(
                    ctypes.c_double)), keys.ctypes.data_as(
                ctypes.POINTER(
                    ctypes.c_int)), len(keys), level)

        if ID is None:
            raise go_error()

        if self.ID is not None:
            self.free()

        self.ID = ID
