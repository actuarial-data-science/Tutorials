import ctypes
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.keys import SecretKey, PublicKey, RelinearizationKey, GaloisKey
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.object import Object


class KeyGenerator(Object):
    """Decryptor is a class used to generate keys.
    """
    def __init__(self, ID: str, params: Parameters):
        self.Parameters = params
        Object.__init__(self, ID)

    def gen_secret_key(self) -> SecretKey:
        """Generates a new secret key.
           A secret key is a single polynomial s.

        Returns:
            SecretKey (SecretKey): the generated secret key.
        """
        sk = so.GenSecretKey
        sk.argtypes = [ctypes.c_char_p]
        sk.restype = ctypes.c_char_p
        ID = sk(self.ID)
        if ID is None:
            raise go_error()
        return SecretKey(ID)

    def gen_public_key(self, sk: SecretKey) -> PublicKey:
        """Generates a new public key from a scecret key.
           A public key is of the form [-as + e, a].

        Args:
            sk (SecretKey): a secret key.

        Returns:
            PublicKey (PublicKey): the generated public key.
        """

        if not isinstance(sk, SecretKey):
            raise ValueError("invalid input: sk must be of type SecretKey")

        pk = so.GenPublicKey
        pk.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        pk.restype = ctypes.c_char_p
        ID = pk(self.ID, sk.ID)
        if ID is None:
            raise go_error()
        return PublicKey(ID)

    def gen_relinearization_key(self, sk: SecretKey) -> RelinearizationKey:
        """Generates a new relinearization key from a secret key.
           A relinearization key is of the form [-as + s^2 + e, a].

        Args:
            sk (SecretKey): a secret key.

        Returns:
            RelinearizationKey (RelinearizationKey): the generated relinearization key.
        """

        if not isinstance(sk, SecretKey):
            raise ValueError("invalid input: sk must be of type SecretKey")

        rlk = so.GenRelinearizationKey
        rlk.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        rlk.restype = ctypes.c_char_p
        ID = rlk(self.ID, sk.ID)
        if ID is None:
            raise go_error()
        return RelinearizationKey(ID)

    def gen_galois_key(self, sk: SecretKey, galEl: int) -> GaloisKey:
        """Generates a new Galois key from a secret key.
           Galois key enable automorphisms of the form pi(galEl): X^{i} -> X^{i*galEl} mod X^{N} + 1 on a ciphertext.
           A Galois key is of the form [-a*pi^{-1}(s) + s + e, a].

        Args:
            sk (SecretKey): a secret key.
            galEl (int): the Galois element.

        Returns:
            GaloisKey (GaloisKey): the generated Galois key.
        """

        if not isinstance(sk, SecretKey):
            raise ValueError("invalid input: sk must be of type SecretKey")

        if not isinstance(galEl, int):
            raise ValueError("invalid input: galEl must be of type int")

        gk = so.GenGaloisKey
        gk.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t]
        gk.restype = ctypes.c_char_p
        ID = gk(self.ID, sk.ID, galEl)
        if ID is None:
            raise go_error()
        return GaloisKey(ID)

    def gen_conjugation_key(self, sk: SecretKey) -> GaloisKey:
        """Generates a new Galois key for homomorphic conjugation key from a secret key.

        Args:
            sk (SecretKey): a secret key.

        Returns:
            GaloisKey (GaloisKey): the generated Galois key.
        """
        return self.gen_galois_key(
            sk, self.Parameters.galois_element_for_conjugation())

    def gen_rotation_key(self, sk: SecretKey, k: int) -> GaloisKey:
        """Generates a new Galois key for homomorphic rotation key from a secret key.

        Args:
            sk (SecretKey): a secret key.

        Returns:
            GaloisKey (GaloisKey): the generated Galois key.
        """
        return self.gen_galois_key(
            sk, self.Parameters.galois_element_for_rotation_by(k))


def new_key_generator(params: Parameters) -> KeyGenerator:
    """Instantiates a new KeyGenerator.

    Args:
        params (Parameters): the scheme parameters.

    Returns:
        KeyGenerator (KeyGenerator): a new instance of KeyGenerator.
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    kgen = so.NewKeyGenerator
    kgen.argtypes = [ctypes.c_char_p]
    kgen.restype = ctypes.c_char_p
    ID = kgen(params.ID)
    if ID is None:
        raise go_error()
    return KeyGenerator(ID, params)
