import ctypes
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.object import Object
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.keys import SecretKey, PublicKey
from tuneinsight.lattigo.operands import Plaintext, Ciphertext


class Encryptor(Object):
    """Encryptor is a class used to encrypt plaintexts
    """
    def __init__(self, ID: str):
        Object.__init__(self, ID)

    def encrypt(self, pt: Plaintext) -> Ciphertext:
        """Return the encryption of a plaintext on a newly allocated ciphertext

        Args:
            pt (Plaintext): the plaintext to encrypt

        Returns:
            Ciphertext (Ciphertext): the encrypted plaintext as a ciphertext
        """

        if not isinstance(pt, Plaintext):
            raise ValueError("invalid input: pt must be of type Plaintext")

        encrypt = so.EncryptNew
        encrypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        encrypt.restype = ctypes.c_char_p
        ID = encrypt(self.ID, pt.ID)
        if ID is None:
            raise go_error()
        return Ciphertext(ID)


def new_encryptor(
    params: Parameters,
    key: [
        SecretKey,
        PublicKey]) -> Encryptor:
    """Instantiates a new Encryptor.

    Args:
        params (Parameters): the scheme parameters
        key (SecretKey, Publickey): a public or secret key

    Returns:
        Decryptor (Decryptor): a new instance of Encryptor
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    if not isinstance(key, (SecretKey, PublicKey)):
        raise ValueError("invalid input: key must be of type (SecretKey, PublicKey)")

    enc = so.NewEncryptor
    enc.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    enc.restype = ctypes.c_char_p
    ID = enc(params.ID, key.ID)
    if ID is None:
        raise go_error()
    return Encryptor(ID)
