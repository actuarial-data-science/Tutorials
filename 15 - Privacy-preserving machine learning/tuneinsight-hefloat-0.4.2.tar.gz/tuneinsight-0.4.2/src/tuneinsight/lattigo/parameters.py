import ctypes
from typing import List
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.object import Object


class Parameters(Object):
    """Parameters is a class used to store the scheme parameters.
    """
    def __init__(self, ID: str, log_n: int, log_scale: int, max_level: int):

        Object.__init__(self, ID)

        self.logn = log_n
        self.logscale = log_scale
        self.maxlevel = max_level

    def log_n(self) -> int:
        """Returns the log2 of the ring degree.
        """
        return self.logn

    def slots(self) -> int:
        """Returns the the number of slots that a plaintext can store.
        """
        return 1<<self.log_slots()

    def log_slots(self) -> int:
        """Returns the the log2 of the number of slots that a plaintext can store.
        """
        return self.logn - 1

    def log_q(self) -> float:
        """Returns the log2 of the modulus Q
        """
        get_log_q = so.ParametersLogQ
        get_log_q.argtypes = [ctypes.c_char_p]
        get_log_q.restype = ctypes.c_double

        log_q = get_log_q(self.ID)

        if log_q == -1:
            raise go_error()

        return log_q

    def log_p(self) -> float:
        """Returns the log2 of the modulus P
        """
        get_log_p = so.ParametersLogP
        get_log_p.argtypes = [ctypes.c_char_p]
        get_log_p.restype = ctypes.c_double

        log_p = get_log_p(self.ID)

        if log_p == -1:
            raise go_error()

        return log_p

    def default_scale(self) -> int:
        """Returns the default scaling factor.
        """
        return 1 << self.logscale

    def max_level(self) -> int:
        """Returns the maximum level at which plaintext and ciphertext can be created.
        """
        return self.maxlevel

    def scale_at_level(self, level: int) -> float:
        """Returns the prime factor of a given level. This prime factor is the value by which
           a ciphertext will be divided by on the next call of Evaluator.rescale.
        """

        if not isinstance(level, int):
            raise ValueError("invalid input: level must be of type int")

        scale_at_level = so.ScaleAtLevel
        scale_at_level.argtypes = [ctypes.c_char_p, ctypes.c_size_t]
        scale_at_level.restype = ctypes.c_double

        scale = scale_at_level(self.ID, level)

        if scale == -1:
            raise go_error()

        return scale

    def galois_element_for_conjugation(self) -> int:
        """Returns the Galois element used for the automorphism that acts as the complex conjugate.
        """
        galEl = so.GaloisElementForComplexConjugation
        galEl.argtypes = [ctypes.c_char_p]
        galEl.restype = ctypes.c_size_t

        g = galEl(self.ID)

        if g == 0:
            raise go_error()

        return g

    def galois_element_for_rotation_by(self, k: int) -> int:
        """Returns the Galois element used for the automorphism that acts as cyclic rotation by k position to the left.
        """

        if not isinstance(k, int):
            raise ValueError("invalid input: k must be of type int")

        galEl = so.GaloisElementForRotation
        galEl.argtypes = [ctypes.c_char_p, ctypes.c_int]
        galEl.restype = ctypes.c_size_t

        g = galEl(self.ID, k)

        if g == 0:
            raise go_error()

        return g


def new_parameters(log_qi: List[int], log_default_scale: int, log_pi: List[int]) -> Parameters:
    """Instantiates a new set of Parameters.

    Args:
        log_qi (list[int]): the log2 of the ciphertext prime moduli.
        log_pi (list[int]): the log2 of the evalation key auxiliary prime moduli.

    Returns:
        Parameters (Parameters): a new instance of Parameters.
    """

    if not isinstance(log_qi, List):
        raise ValueError("invalid input: log_qi must be of type List[int]")

    if not isinstance(log_default_scale, int):
        raise ValueError("invalid input: log_default_scale must be of type int")

    if not isinstance(log_pi, List):
        raise ValueError("invalid input: log_pi must be of type List[int]")

    log_qp = sum(log_qi) + sum(log_pi)

    if log_qp <= 27:
        log_n = 10
    elif 27 < log_qp <= 54:
        log_n = 11
    elif 54 < log_qp <= 109:
        log_n = 12
    elif 109 < log_qp <= 218:
        log_n = 13
    elif 218 < log_qp <= 438:
        log_n = 14
    elif 438 < log_qp <= 881:
        log_n = 15
    elif 881 < log_qp <= 1791:
        log_n = 16
    else:
        raise ValueError(
            "invalid parameters: would require logN17 to support 128-bit security, but logN17 isn't supported. Reduce the number of supported depth")

    return new_parameters_from_literal(log_n, log_default_scale, log_qi, log_pi)


def new_parameters_from_literal(
        LogN: int,
        LogScale: int,
        LogQi: List[int],
        LogPi: List[int]) -> Parameters:
    """Instantiates a new set of Parameters.

    Args:
        LogN (int): the log2 of the ring degree.
        LogScale (int): the log2 of the default scaling factor.
        LogQi (list[int]): the log2 of the primes factors of the ciphertext modulus Q.
        LogPi (list[int]): the log2 of the primes factor of the auxiliary modulus P.

    Returns:
        Parameters (Parameters): a new instance of Parameters.

    Notes:
        This method can be used to instantiate insecure parameters.
    """

    if not isinstance(LogN, int):
        raise ValueError("invalid input: LogN must be of type int")

    if not isinstance(LogScale, int):
        raise ValueError("invalid input: LogScale must be of type int")

    if not isinstance(LogQi, List):
        raise ValueError("invalid input: LogQi must be of type List[int]")

    if not isinstance(LogPi, List):
        raise ValueError("invalid input: LogPi must be of type List[int]")

    params = so.NewParameters

    params.argtypes = [
        ctypes.c_size_t,
        ctypes.c_size_t,
        ctypes.c_size_t * len(LogQi), ctypes.c_size_t,
        ctypes.c_size_t * len(LogPi), ctypes.c_size_t,
    ]

    params.restype = ctypes.c_char_p

    ID = params(
        LogN,
        LogScale,
        (ctypes.c_size_t * len(LogQi))(*LogQi), len(LogQi),
        (ctypes.c_size_t * len(LogPi))(*LogPi), len(LogPi),
    )

    if ID is None:
        raise go_error()

    return Parameters(ID, LogN, LogScale, len(LogQi) - 1)
