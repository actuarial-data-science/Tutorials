import ctypes
from math import log
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.object import Object


class Operand(Object):
    """Operand is a class used to store generic rlwe operands.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)

    def scale(self) -> float:
        """Returns the scaling factor of the operand as a float.
        """
        getscale = so.GetOperandScalingFactor
        getscale.argtypes = [ctypes.c_char_p]
        getscale.restype = ctypes.c_double

        scale = getscale(self.ID)

        if scale == -1:
            go_error()

        return scale

    def log_scale(self):
        """Returns the log2 of the scaling factor of the operand as a float.
        """
        return log(self.scale(), 2)

    def set_scale(self, scale: float):
        """Sets the scaling factor of the operand.
        """

        if not isinstance(scale, float):
            raise ValueError("invalid scale: degree must be of type float")

        set_scale = so.SetOperandScalingfactor
        set_scale.argtypes = [ctypes.c_char_p, ctypes.c_double]
        set_scale.restype = ctypes.c_size_t

        if set_scale(self.ID, scale) == 0:
            go_error()

    def set_is_batched(self, isBatched: bool):
        """Sets the isbatched flag of the operand.
        """
        if not isinstance(isBatched, bool):
            raise ValueError("invalid isBatched: degree must be of type bool")

        set_is_batched = so.SetOperandIsBatched
        set_is_batched.argtypes = [ctypes.c_char_p, ctypes.c_size_t]
        set_is_batched.restype = ctypes.c_size_t

        if set_is_batched(self.ID, 1 if isBatched else 0) == 0:
            go_error()

    def is_batched(self) -> bool:
        """Returns true if the operand is batched.
        """
        get_is_batched = so.GetOperandIsbatched
        get_is_batched.argtypes = [ctypes.c_char_p]
        get_is_batched.restype = ctypes.c_size_t

        isBatched = get_is_batched(self.ID)

        if isBatched == -1:
            go_error()

        return isBatched == 1

    def level(self) -> int:
        """Returns the level of the operand as an int.
        """
        get_level = so.GetOperandLevel
        get_level.argtypes = [ctypes.c_char_p]
        get_level.restype = ctypes.c_size_t

        level = get_level(self.ID)

        if level == -1:
            go_error()

        return level

    def degree(self) -> int:
        """Returns the degree of the operand as an int.
        """
        get_degree = so.GetOperandDegree
        get_degree.argtypes = [ctypes.c_char_p]
        get_degree.restype = ctypes.c_size_t

        degree = get_degree(self.ID)

        if degree == -1:
            go_error()

        return degree


class Ciphertext(Operand):
    """Ciphertext is a class used to store a ciphertext.
    """
    def __init__(self, ID):
        Operand.__init__(self, ID)


def new_ciphertext(params: Parameters, degree: int = None, level: int = None) -> Ciphertext:
    """Allocates a new Ciphertext.

    Args:
        params (Parameters): the scheme parameters.
        degree (int): the degree of the ciphertext (by default 1).
        level (int): the level of the ciphertext (by default Parameters.max_level())

    Returns:
        Ciphertext (Ciphertext): a new instance of Ciphertext.

    Notes:
        The scaling factor is set to Parameters.default_scale().
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    if degree is not None and not isinstance(degree, int):
        raise ValueError("invalid input: degree must be of type int or None")

    if level is not None and not isinstance(level, int):
        raise ValueError("invalid input: level must be of type int or None")

    if degree is None:
        degree = 1

    if level is None:
        level = params.max_level()

    ct = so.NewCiphertext
    ct.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_size_t]
    ct.restype = ctypes.c_char_p

    ID = ct(params.ID, degree, level)

    if ID is None:
        go_error()

    return Ciphertext(ID)


class Plaintext(Operand):
    """Allocates a new Plaintext.

    Args:
        params (Parameters): the scheme parameters.
        level (int): the level of the plaintext (by default Parameters.max_level())

    Returns:
        Plaintext (Plaintext): a new instance of Plaintext.

    Notes:
        The scaling factor is set to Parameters.default_scale().
    """
    def __init__(self, ID):
        Operand.__init__(self, ID)


def new_plaintext(params: Parameters, level: int = None) -> Plaintext:

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    if level is not None and not isinstance(level, int):
        raise ValueError("invalid input: level must be of type int or None")

    pt = so.NewPlaintext
    pt.argtypes = [ctypes.c_char_p, ctypes.c_int]
    pt.restype = ctypes.c_char_p

    if level is None:
        level = params.max_level()

    ID = pt(params.ID, level)

    if ID is None:
        go_error()

    return Plaintext(ID)
