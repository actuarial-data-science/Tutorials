import ctypes
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.object import Object
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.keys import SecretKey
from tuneinsight.lattigo.operands import Plaintext, Ciphertext


class Decryptor(Object):
    """Decryptor is a class used to decrypt ciphertexts.
    """
    def __init__(self, ID:str):
        Object.__init__(self, ID)

    def decrypt(self, ct: Ciphertext) -> Plaintext:
        """Return the decryption of a ciphertext on a newly allocated plaintext.

        Args:
            ct (Ciphertext): the ciphertext to decrypt.

        Returns:
            Plaintext (Plaintext): the decrypted ciphertext as a plaintext.
        """

        if not isinstance(ct, Ciphertext):
            raise ValueError("invalid input: ct must be of type Ciphertext")

        decrypt = so.DecryptNew
        decrypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        decrypt.restype = ctypes.c_char_p
        ID = decrypt(self.ID, ct.ID)
        if ID is None:
            raise go_error()
        return Plaintext(ID)


def new_decryptor(params: Parameters, sk: SecretKey) -> Decryptor:
    """Instantiates a new Decryptor.

    Args:
        params (Parameters): the scheme parameters.
        sk (SecretKey): a secret key.

    Returns:
        Decryptor (Decryptor): a new instance of Decryptor.
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    if not isinstance(sk, SecretKey):
        raise ValueError("invalid input: sk must be of type SecretKey")

    decryptor = so.NewDecryptor
    decryptor.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    decryptor.restype = ctypes.c_char_p
    ID = decryptor(params.ID, sk.ID)
    if ID is None:
        raise go_error()
    return Decryptor(ID)
