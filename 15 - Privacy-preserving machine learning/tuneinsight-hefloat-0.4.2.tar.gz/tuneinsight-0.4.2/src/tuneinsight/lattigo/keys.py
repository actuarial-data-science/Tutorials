import ctypes
from typing import List
from tuneinsight.lattigo.library import so, go_error
from tuneinsight.lattigo.object import Object


class SecretKey(Object):
    """SecretKey is a class that stores a secret key object.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)


class PublicKey(Object):
    """PublicKey is a class that stores a public key object.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)


class RelinearizationKey(Object):
    """RelinearizationKey is a class that stores a relinearization key object.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)


class GaloisKey(Object):
    """GaloisKey is a class that stores a Galois key object.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)


class EvaluationKeySet(Object):
    """EvaluationKeySet is a class that stores an evaluation key set object.
    """
    def __init__(self, ID):
        Object.__init__(self, ID)

    def add_key(self, key: [RelinearizationKey, GaloisKey]):
        """Adds a key to the evaluation key set.

        Args:
            key (RelinearizationKey, GaloisKey): the key to add to the evaluation key set.
        """
        add_key = so.AddKeyToEvaluationKeySet
        add_key.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        add_key.restype = ctypes.c_size_t
        if add_key(self.ID, key.ID) == 0:
            raise go_error()


def new_evaluation_key_set(
        rlk: RelinearizationKey = None,
        gks: List[GaloisKey] = None) -> EvaluationKeySet:
    """Instantiates a new EvaluationKeySet.

    Args:
        rlk (RelinearizationKey): a relinearization key.
        gks (list[GaloisKey]): a list of Galois keys.

    Returns:
        EvaluationKeySet (EvaluationKeySet): a new instance of EvaluationKeySet.
    """

    if rlk is not None and not isinstance(rlk, RelinearizationKey):
        raise ValueError("invalid input: rlk must be of type (None, RelinearizationKey)")

    if gks is not None and not isinstance(gks, List[GaloisKey]):
        raise ValueError("invalid input: gks must be of type (None, List[GaloisKey])")

    evk = so.NewMemEvaluationKeySet
    evk.restype = ctypes.c_char_p
    ID = evk()
    if ID is None:
        raise go_error()

    evk = EvaluationKeySet(ID)

    if rlk is not None:
        evk.add_key(rlk)

    if gks is not None:
        for gk in gks:
            evk.add_key(gk)

    return evk
