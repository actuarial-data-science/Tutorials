import ctypes
from pathlib import Path
from os.path import exists
import os
import platform
import distutils.ccompiler

# Location of shared library
cwd = Path(__file__).absolute().parent
arch = platform.machine()
oss = platform.system().lower()
extension = distutils.ccompiler.new_compiler().shared_lib_extension
cryptolib_path = os.path.join(cwd,f"lattigo-{oss}_{arch}{extension}")
if not exists(cryptolib_path):
    raise FileNotFoundError(
        "Could not find the lattigo library. Your platform might not be supported.")
so = ctypes.cdll.LoadLibrary(cryptolib_path)

def go_error() -> Exception:
    """Raise a python exception from the latest go error."""
    get_go_error = so.GetLastError
    get_go_error.restype = ctypes.c_char_p
    error_message = get_go_error()
    return Exception(error_message)
