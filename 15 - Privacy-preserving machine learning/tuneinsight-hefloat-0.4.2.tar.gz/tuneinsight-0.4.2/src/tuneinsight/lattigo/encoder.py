import ctypes
import numpy as np
from tuneinsight.lattigo.library import go_error, so
from tuneinsight.lattigo.object import Object
from tuneinsight.lattigo.parameters import Parameters
from tuneinsight.lattigo.operands import Plaintext

class Encoder(Object):
    """Encoder is a class used to encrypt one dimensional np.ndarrays
       on a plaintext.
    """
    def __init__(self, ID:str, params:Parameters):
        Object.__init__(self, ID)
        self.Parameters = params

    def encode(
            self,
            values: np.ndarray,
            pt: Plaintext):
        """Encodes a one dimensional np.ndarray of dtype=[float, complex] on a pre-allocated plaintext.

        Args:
            values (np.ndarray): the one dimensional np.ndarray to encode
            pt (Plaintext): the plaintext on which to encode the values

        Notes:
            A plaintext can hold up to Parameters.slots() values. If the np.ndarray is smaller
            than the number of slots, the values to be encoded will be padded with zero until
            the size of the vector reaches the number of slots.
        """

        if not isinstance(values, np.ndarray):
            raise ValueError("invalid input: values must be of type np.ndarray")

        if not isinstance(pt, Plaintext):
            raise ValueError("invalid input: pt must be of type Plaintext")

        encode = so.Encode

        encode.argtypes = [
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_double), ctypes.c_size_t,
            ctypes.c_int,
            ctypes.c_char_p,
        ]

        encode.restype = ctypes.c_size_t

        if values.dtype == "float":
            isReal = 1
        elif values.dtype == "complex":
            isReal = 0
        else:
            raise ValueError(
                "invalid np.ndarray.dtype: must be `float` or `complex`")

        if encode(
                self.ID,
                values.ctypes.data_as(
                    ctypes.POINTER(
                ctypes.c_double)),
                len(values),
                isReal,
                pt.ID) == 0:
            raise go_error()

    def decode(
            self,
            pt: Plaintext,
            values: np.ndarray):
        """Decodes a plaintext on a pre-allocated one dimensional np.ndarray.

        Args:
            pt (Plaintext): the plaintext to decode
            values (np.ndarray): the one dimensional np.ndarray to recieve the decoded plaintext

        Notes:
            A plaintext can hold up to Parameters.slots() values. If the np.ndarray to receive the decodded
            result is smaller than the number of slots, the result will be truncated.
        """

        if not isinstance(pt, Plaintext):
            raise ValueError("invalid input: pt must be of type Plaintext")

        if not isinstance(values, np.ndarray):
            raise ValueError("invalid input: values must be of type np.ndarray")

        decode = so.Decode

        decode.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_double), ctypes.c_size_t,
            ctypes.c_int,
        ]

        decode.restype = ctypes.c_size_t

        if values.dtype == "float":
            isReal = 1
        elif values.dtype == "complex":
            isReal = 0
        else:
            raise ValueError(
                "invalid np.ndarray.dtype: must be `float` or `complex`")

        if decode(
                self.ID,
                pt.ID,
                values.ctypes.data_as(
                    ctypes.POINTER(
                ctypes.c_double)),
                len(values),
                isReal) == 0:
            raise go_error()


def new_encoder(params: Parameters) -> Encoder:
    """Instantiates a new Encoder.

    Args:
        params (Parameters): the scheme parameters

    Returns:
        Decryptor (Decryptor): a new instance of Encoder
    """

    if not isinstance(params, Parameters):
        raise ValueError("invalid input: params must be of type Parameters")

    encoder = so.NewEncoder
    encoder.argtypes = [ctypes.c_char_p]
    encoder.restype = ctypes.c_char_p
    ID = encoder(params.ID)
    if ID is None:
        raise go_error()
    return Encoder(ID, params)
