from typing import List
import numpy as np

basis_type_list = ["Standard", "Chebyshev"]

class Polynomial():
    """Polynomial is a class used to store a polynomial.
    """
    def __init__(
            self,
            coeffs: np.ndarray,
            basis: str = None,
            interval: List[float] = None):
        self.coeffs = np.array(coeffs[:], dtype="complex")

        self.basis = basis

        if self.basis is None:
            self.basis = basis_type_list[0]

        if self.basis not in basis_type_list:
            raise ValueError(
                "Polynomial: invalid basis type, must be `Standard` or `Chebyshev`")

        self.interval = interval

    def change_of_basis(self) -> List[float]:
        """Returns the change of basis y = a + bx that should be applied on a ciphertext before
           calling the polynomial evaluation. If the polynomial is in the Standard basis then
           a = 0 and b = 1, which acts as the identity.
        """

        if self.interval is None:
            return [0, 1]

        a = self.interval[0]
        b = self.interval[1]

        return [(-b - a) / (b - a), 2 / (b - a)]
