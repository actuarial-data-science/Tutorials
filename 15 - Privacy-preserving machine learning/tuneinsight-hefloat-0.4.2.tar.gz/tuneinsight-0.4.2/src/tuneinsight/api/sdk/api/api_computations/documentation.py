from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import Client
from ...models.computation_definition import ComputationDefinition
from ...models.documentation_response_200 import DocumentationResponse200
from ...models.documentation_response_403 import DocumentationResponse403
from ...types import Response


def _get_kwargs(
    *,
    client: Client,
    json_body: ComputationDefinition,
) -> Dict[str, Any]:
    url = "{}/computation/documentation".format(client.base_url)

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    json_json_body = json_body.to_dict()

    return {
        "method": "post",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "json": json_json_body,
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = DocumentationResponse200.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.BAD_REQUEST:
        response_400 = cast(str, response.json())
        return response_400
    if response.status_code == HTTPStatus.FORBIDDEN:
        response_403 = DocumentationResponse403.from_dict(response.json())

        return response_403
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = cast(str, response.json())
        return response_422
    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        response_500 = cast(str, response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Response[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Client,
    json_body: ComputationDefinition,
) -> Response[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    """Request a markdown description of a computation given a definition.

    Args:
        json_body (ComputationDefinition): Generic computation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[DocumentationResponse200, DocumentationResponse403, str]]
    """

    kwargs = _get_kwargs(
        client=client,
        json_body=json_body,
    )

    response = httpx.request(
        verify=client.verify_ssl,
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Client,
    json_body: ComputationDefinition,
) -> Optional[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    """Request a markdown description of a computation given a definition.

    Args:
        json_body (ComputationDefinition): Generic computation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[DocumentationResponse200, DocumentationResponse403, str]]
    """

    return sync_detailed(
        client=client,
        json_body=json_body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Client,
    json_body: ComputationDefinition,
) -> Response[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    """Request a markdown description of a computation given a definition.

    Args:
        json_body (ComputationDefinition): Generic computation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[DocumentationResponse200, DocumentationResponse403, str]]
    """

    kwargs = _get_kwargs(
        client=client,
        json_body=json_body,
    )

    async with httpx.AsyncClient(verify=client.verify_ssl) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Client,
    json_body: ComputationDefinition,
) -> Optional[Union[DocumentationResponse200, DocumentationResponse403, str]]:
    """Request a markdown description of a computation given a definition.

    Args:
        json_body (ComputationDefinition): Generic computation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[DocumentationResponse200, DocumentationResponse403, str]]
    """

    return (
        await asyncio_detailed(
            client=client,
            json_body=json_body,
        )
    ).parsed
