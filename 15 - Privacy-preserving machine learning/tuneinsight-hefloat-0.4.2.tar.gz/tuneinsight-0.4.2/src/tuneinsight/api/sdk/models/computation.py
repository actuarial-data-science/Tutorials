from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.computation_status import ComputationStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.computation_definition import ComputationDefinition
    from ..models.measurement import Measurement


T = TypeVar("T", bound="Computation")


@attr.s(auto_attribs=True)
class Computation:
    """Metadata of a computation.

    Attributes:
        id (str): Identifier of a computation, unique across all computing nodes.
        status (ComputationStatus): Status of the computation.
        definition (ComputationDefinition): Generic computation.
        progress (Union[Unset, int]):
        started_at (Union[Unset, str]):
        egress (Union[Unset, int]): keeps track of the number of bytes sent during a computation to serve as a bandwidth
            measure
        description (Union[Unset, str]):
        updated_at (Union[Unset, str]):
        created_at (Union[Unset, str]):
        error (Union[Unset, List[str]]): Error messages.
        local (Union[Unset, bool]):
        measurements (Union[Unset, List['Measurement']]): list of benchmarking measurements done on the computation
        ended_at (Union[Unset, str]):
        ingress (Union[Unset, int]): keeps track of the number of bytes received during a computation to serve as a
            bandwidth measure
        results (Union[Unset, List[str]]): Identifier(s) of the resulting data object(s). Available only when the status
            is completed.
        visible (Union[Unset, bool]): False if the computation is internal and should not be displayed to the user by
            default
    """

    id: str
    status: ComputationStatus
    definition: "ComputationDefinition"
    progress: Union[Unset, int] = UNSET
    started_at: Union[Unset, str] = UNSET
    egress: Union[Unset, int] = UNSET
    description: Union[Unset, str] = UNSET
    updated_at: Union[Unset, str] = UNSET
    created_at: Union[Unset, str] = UNSET
    error: Union[Unset, List[str]] = UNSET
    local: Union[Unset, bool] = UNSET
    measurements: Union[Unset, List["Measurement"]] = UNSET
    ended_at: Union[Unset, str] = UNSET
    ingress: Union[Unset, int] = UNSET
    results: Union[Unset, List[str]] = UNSET
    visible: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        status = self.status.value

        definition = self.definition.to_dict()

        progress = self.progress
        started_at = self.started_at
        egress = self.egress
        description = self.description
        updated_at = self.updated_at
        created_at = self.created_at
        error: Union[Unset, List[str]] = UNSET
        if not isinstance(self.error, Unset):
            error = self.error

        local = self.local
        measurements: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.measurements, Unset):
            measurements = []
            for measurements_item_data in self.measurements:
                measurements_item = measurements_item_data.to_dict()

                measurements.append(measurements_item)

        ended_at = self.ended_at
        ingress = self.ingress
        results: Union[Unset, List[str]] = UNSET
        if not isinstance(self.results, Unset):
            results = self.results

        visible = self.visible

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "status": status,
                "definition": definition,
            }
        )
        if progress is not UNSET:
            field_dict["progress"] = progress
        if started_at is not UNSET:
            field_dict["startedAt"] = started_at
        if egress is not UNSET:
            field_dict["egress"] = egress
        if description is not UNSET:
            field_dict["description"] = description
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if error is not UNSET:
            field_dict["error"] = error
        if local is not UNSET:
            field_dict["local"] = local
        if measurements is not UNSET:
            field_dict["measurements"] = measurements
        if ended_at is not UNSET:
            field_dict["endedAt"] = ended_at
        if ingress is not UNSET:
            field_dict["ingress"] = ingress
        if results is not UNSET:
            field_dict["results"] = results
        if visible is not UNSET:
            field_dict["visible"] = visible

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.computation_definition import ComputationDefinition
        from ..models.measurement import Measurement

        d = src_dict.copy()
        id = d.pop("id")

        status = ComputationStatus(d.pop("status"))

        definition = ComputationDefinition.from_dict(d.pop("definition"))

        progress = d.pop("progress", UNSET)

        started_at = d.pop("startedAt", UNSET)

        egress = d.pop("egress", UNSET)

        description = d.pop("description", UNSET)

        updated_at = d.pop("updatedAt", UNSET)

        created_at = d.pop("createdAt", UNSET)

        error = cast(List[str], d.pop("error", UNSET))

        local = d.pop("local", UNSET)

        measurements = []
        _measurements = d.pop("measurements", UNSET)
        for measurements_item_data in _measurements or []:
            measurements_item = Measurement.from_dict(measurements_item_data)

            measurements.append(measurements_item)

        ended_at = d.pop("endedAt", UNSET)

        ingress = d.pop("ingress", UNSET)

        results = cast(List[str], d.pop("results", UNSET))

        visible = d.pop("visible", UNSET)

        computation = cls(
            id=id,
            status=status,
            definition=definition,
            progress=progress,
            started_at=started_at,
            egress=egress,
            description=description,
            updated_at=updated_at,
            created_at=created_at,
            error=error,
            local=local,
            measurements=measurements,
            ended_at=ended_at,
            ingress=ingress,
            results=results,
            visible=visible,
        )

        computation.additional_properties = d
        return computation

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
