from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.authorization_status import AuthorizationStatus
from ..models.client import Client
from ..models.project_base_workflow_type import ProjectBaseWorkflowType
from ..models.topology import Topology
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.computation_definition import ComputationDefinition
    from ..models.computation_policy import ComputationPolicy
    from ..models.local_data_selection_definition import LocalDataSelectionDefinition


T = TypeVar("T", bound="ProjectDefinition")


@attr.s(auto_attribs=True)
class ProjectDefinition:
    """
    Attributes:
        allow_shared_edit (Union[Unset, bool]): True if this project can be modified after being shared. Modifications
            of a shared project will be broadcasted to the network
        authorization_status (Union[Unset, AuthorizationStatus]): Authorization status of the project
        description (Union[Unset, None, str]):
        run_async (Union[Unset, bool]): flag indicating if computation should be run asynchronously
        allow_clear_query (Union[Unset, bool]): [Dangerous, can lead to cross code data share] True if it is allowed for
            a client to query the data source all participants of the project and return the clear text result
        local_data_selection_definition (Union[Unset, LocalDataSelectionDefinition]): datasource selection definition. A
            selection is a "query" or data selection definition to run on the datasource
        name (Union[Unset, str]):
        network_id (Union[Unset, str]): id to uniquely identify the network
        query_timeout (Union[Unset, int]): Timeout for the data source queries Default: 30.
        topology (Union[Unset, Topology]): Network Topologies. 'star' or 'tree'. In star topology all nodes are
            connected to a central node. In tree topology all nodes are connected and aware of each other.
        workflow_json (Union[Unset, str]): JSON representation of the workflow UI in the frontend
        created_by_node (Union[Unset, str]): ID of node where the project was first created
        created_with_client (Union[Unset, Client]): Type of client that communicates with the agent API
        data_source_auto_match (Union[Unset, bool]): whether or not to automatically assign the first matching
            datasource when the project is shared with other nodes
        local (Union[Unset, None, bool]): True if the project's computation should run only with local data (not
            configured the network)
        locked (Union[Unset, bool]): True if the project is read-only (likely because it has already been shared)
        query (Union[Unset, str]): String of the query a data source into a data object
        unique_id (Union[Unset, str]): Unique identifier of a project.
        computation_definition (Union[Unset, ComputationDefinition]): Generic computation.
        created_by_user (Union[Unset, str]): ID of user who created the project
        data_source_id (Union[Unset, None, str]): Unique identifier of a data source.
        dpia (Union[Unset, str]):
        policy (Union[Unset, ComputationPolicy]): policy to validate a specific computation
        shared (Union[Unset, bool]): True if the project has once been shared across the participants
        workflow_type (Union[Unset, ProjectBaseWorkflowType]): type of the workflow UI in the frontend
        authorized_users (Union[Unset, List[str]]): The IDs of the users who can run the project
        broadcast (Union[Unset, bool]): Temporary field. Always set to false. Only used for server-server communication
        data_source_type (Union[Unset, str]): Type of the data source to share to other nodes to match with their data
            source of the same type
        participants (Union[Unset, None, List[str]]): List of nodes involved in the project's collaboration
    """

    allow_shared_edit: Union[Unset, bool] = UNSET
    authorization_status: Union[Unset, AuthorizationStatus] = UNSET
    description: Union[Unset, None, str] = UNSET
    run_async: Union[Unset, bool] = UNSET
    allow_clear_query: Union[Unset, bool] = UNSET
    local_data_selection_definition: Union[Unset, "LocalDataSelectionDefinition"] = UNSET
    name: Union[Unset, str] = UNSET
    network_id: Union[Unset, str] = UNSET
    query_timeout: Union[Unset, int] = 30
    topology: Union[Unset, Topology] = UNSET
    workflow_json: Union[Unset, str] = UNSET
    created_by_node: Union[Unset, str] = UNSET
    created_with_client: Union[Unset, Client] = UNSET
    data_source_auto_match: Union[Unset, bool] = UNSET
    local: Union[Unset, None, bool] = UNSET
    locked: Union[Unset, bool] = UNSET
    query: Union[Unset, str] = UNSET
    unique_id: Union[Unset, str] = UNSET
    computation_definition: Union[Unset, "ComputationDefinition"] = UNSET
    created_by_user: Union[Unset, str] = UNSET
    data_source_id: Union[Unset, None, str] = UNSET
    dpia: Union[Unset, str] = UNSET
    policy: Union[Unset, "ComputationPolicy"] = UNSET
    shared: Union[Unset, bool] = UNSET
    workflow_type: Union[Unset, ProjectBaseWorkflowType] = UNSET
    authorized_users: Union[Unset, List[str]] = UNSET
    broadcast: Union[Unset, bool] = UNSET
    data_source_type: Union[Unset, str] = UNSET
    participants: Union[Unset, None, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        allow_shared_edit = self.allow_shared_edit
        authorization_status: Union[Unset, str] = UNSET
        if not isinstance(self.authorization_status, Unset):
            authorization_status = self.authorization_status.value

        description = self.description
        run_async = self.run_async
        allow_clear_query = self.allow_clear_query
        local_data_selection_definition: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.local_data_selection_definition, Unset):
            local_data_selection_definition = self.local_data_selection_definition.to_dict()

        name = self.name
        network_id = self.network_id
        query_timeout = self.query_timeout
        topology: Union[Unset, str] = UNSET
        if not isinstance(self.topology, Unset):
            topology = self.topology.value

        workflow_json = self.workflow_json
        created_by_node = self.created_by_node
        created_with_client: Union[Unset, str] = UNSET
        if not isinstance(self.created_with_client, Unset):
            created_with_client = self.created_with_client.value

        data_source_auto_match = self.data_source_auto_match
        local = self.local
        locked = self.locked
        query = self.query
        unique_id = self.unique_id
        computation_definition: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.computation_definition, Unset):
            computation_definition = self.computation_definition.to_dict()

        created_by_user = self.created_by_user
        data_source_id = self.data_source_id
        dpia = self.dpia
        policy: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.policy, Unset):
            policy = self.policy.to_dict()

        shared = self.shared
        workflow_type: Union[Unset, str] = UNSET
        if not isinstance(self.workflow_type, Unset):
            workflow_type = self.workflow_type.value

        authorized_users: Union[Unset, List[str]] = UNSET
        if not isinstance(self.authorized_users, Unset):
            authorized_users = self.authorized_users

        broadcast = self.broadcast
        data_source_type = self.data_source_type
        participants: Union[Unset, None, List[str]] = UNSET
        if not isinstance(self.participants, Unset):
            if self.participants is None:
                participants = None
            else:
                participants = self.participants

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if allow_shared_edit is not UNSET:
            field_dict["allowSharedEdit"] = allow_shared_edit
        if authorization_status is not UNSET:
            field_dict["authorizationStatus"] = authorization_status
        if description is not UNSET:
            field_dict["description"] = description
        if run_async is not UNSET:
            field_dict["runAsync"] = run_async
        if allow_clear_query is not UNSET:
            field_dict["allowClearQuery"] = allow_clear_query
        if local_data_selection_definition is not UNSET:
            field_dict["localDataSelectionDefinition"] = local_data_selection_definition
        if name is not UNSET:
            field_dict["name"] = name
        if network_id is not UNSET:
            field_dict["networkId"] = network_id
        if query_timeout is not UNSET:
            field_dict["queryTimeout"] = query_timeout
        if topology is not UNSET:
            field_dict["topology"] = topology
        if workflow_json is not UNSET:
            field_dict["workflowJSON"] = workflow_json
        if created_by_node is not UNSET:
            field_dict["createdByNode"] = created_by_node
        if created_with_client is not UNSET:
            field_dict["createdWithClient"] = created_with_client
        if data_source_auto_match is not UNSET:
            field_dict["dataSourceAutoMatch"] = data_source_auto_match
        if local is not UNSET:
            field_dict["local"] = local
        if locked is not UNSET:
            field_dict["locked"] = locked
        if query is not UNSET:
            field_dict["query"] = query
        if unique_id is not UNSET:
            field_dict["uniqueId"] = unique_id
        if computation_definition is not UNSET:
            field_dict["computationDefinition"] = computation_definition
        if created_by_user is not UNSET:
            field_dict["createdByUser"] = created_by_user
        if data_source_id is not UNSET:
            field_dict["dataSourceId"] = data_source_id
        if dpia is not UNSET:
            field_dict["dpia"] = dpia
        if policy is not UNSET:
            field_dict["policy"] = policy
        if shared is not UNSET:
            field_dict["shared"] = shared
        if workflow_type is not UNSET:
            field_dict["workflowType"] = workflow_type
        if authorized_users is not UNSET:
            field_dict["authorizedUsers"] = authorized_users
        if broadcast is not UNSET:
            field_dict["broadcast"] = broadcast
        if data_source_type is not UNSET:
            field_dict["dataSourceType"] = data_source_type
        if participants is not UNSET:
            field_dict["participants"] = participants

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.computation_definition import ComputationDefinition
        from ..models.computation_policy import ComputationPolicy
        from ..models.local_data_selection_definition import LocalDataSelectionDefinition

        d = src_dict.copy()
        allow_shared_edit = d.pop("allowSharedEdit", UNSET)

        _authorization_status = d.pop("authorizationStatus", UNSET)
        authorization_status: Union[Unset, AuthorizationStatus]
        if isinstance(_authorization_status, Unset):
            authorization_status = UNSET
        else:
            authorization_status = AuthorizationStatus(_authorization_status)

        description = d.pop("description", UNSET)

        run_async = d.pop("runAsync", UNSET)

        allow_clear_query = d.pop("allowClearQuery", UNSET)

        _local_data_selection_definition = d.pop("localDataSelectionDefinition", UNSET)
        local_data_selection_definition: Union[Unset, LocalDataSelectionDefinition]
        if isinstance(_local_data_selection_definition, Unset):
            local_data_selection_definition = UNSET
        else:
            local_data_selection_definition = LocalDataSelectionDefinition.from_dict(_local_data_selection_definition)

        name = d.pop("name", UNSET)

        network_id = d.pop("networkId", UNSET)

        query_timeout = d.pop("queryTimeout", UNSET)

        _topology = d.pop("topology", UNSET)
        topology: Union[Unset, Topology]
        if isinstance(_topology, Unset):
            topology = UNSET
        else:
            topology = Topology(_topology)

        workflow_json = d.pop("workflowJSON", UNSET)

        created_by_node = d.pop("createdByNode", UNSET)

        _created_with_client = d.pop("createdWithClient", UNSET)
        created_with_client: Union[Unset, Client]
        if isinstance(_created_with_client, Unset):
            created_with_client = UNSET
        else:
            created_with_client = Client(_created_with_client)

        data_source_auto_match = d.pop("dataSourceAutoMatch", UNSET)

        local = d.pop("local", UNSET)

        locked = d.pop("locked", UNSET)

        query = d.pop("query", UNSET)

        unique_id = d.pop("uniqueId", UNSET)

        _computation_definition = d.pop("computationDefinition", UNSET)
        computation_definition: Union[Unset, ComputationDefinition]
        if isinstance(_computation_definition, Unset):
            computation_definition = UNSET
        else:
            computation_definition = ComputationDefinition.from_dict(_computation_definition)

        created_by_user = d.pop("createdByUser", UNSET)

        data_source_id = d.pop("dataSourceId", UNSET)

        dpia = d.pop("dpia", UNSET)

        _policy = d.pop("policy", UNSET)
        policy: Union[Unset, ComputationPolicy]
        if isinstance(_policy, Unset):
            policy = UNSET
        else:
            policy = ComputationPolicy.from_dict(_policy)

        shared = d.pop("shared", UNSET)

        _workflow_type = d.pop("workflowType", UNSET)
        workflow_type: Union[Unset, ProjectBaseWorkflowType]
        if isinstance(_workflow_type, Unset):
            workflow_type = UNSET
        else:
            workflow_type = ProjectBaseWorkflowType(_workflow_type)

        authorized_users = cast(List[str], d.pop("authorizedUsers", UNSET))

        broadcast = d.pop("broadcast", UNSET)

        data_source_type = d.pop("dataSourceType", UNSET)

        participants = cast(List[str], d.pop("participants", UNSET))

        project_definition = cls(
            allow_shared_edit=allow_shared_edit,
            authorization_status=authorization_status,
            description=description,
            run_async=run_async,
            allow_clear_query=allow_clear_query,
            local_data_selection_definition=local_data_selection_definition,
            name=name,
            network_id=network_id,
            query_timeout=query_timeout,
            topology=topology,
            workflow_json=workflow_json,
            created_by_node=created_by_node,
            created_with_client=created_with_client,
            data_source_auto_match=data_source_auto_match,
            local=local,
            locked=locked,
            query=query,
            unique_id=unique_id,
            computation_definition=computation_definition,
            created_by_user=created_by_user,
            data_source_id=data_source_id,
            dpia=dpia,
            policy=policy,
            shared=shared,
            workflow_type=workflow_type,
            authorized_users=authorized_users,
            broadcast=broadcast,
            data_source_type=data_source_type,
            participants=participants,
        )

        project_definition.additional_properties = d
        return project_definition

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
